
// const paymentAuth = async (req, res , next)=>{
//     try {
//         const user = await User.findOne({ _id: req.id })
//         next()
        
//     } catch (error) {
//         res.status(401).redirect('login')
//     }
// }


// export {
//     paymentAuth
// }